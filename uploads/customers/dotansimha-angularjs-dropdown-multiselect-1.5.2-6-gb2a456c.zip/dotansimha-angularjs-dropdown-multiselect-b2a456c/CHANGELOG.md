Version numbers correspond to `bower.json` version

# 1.0.0

## Features

## Bug Fixes

## Breaking Changes